"""
FUNNEL: A Three-Stage Agentic RAG Architecture for Clinical Documentation
Supplementary code for MethodsX manuscript.
"""

__version__ = "1.0.0"
__author__ = "Rugved Parmar"
